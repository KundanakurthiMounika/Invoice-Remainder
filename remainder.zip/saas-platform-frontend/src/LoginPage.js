import React from 'react';
import axios from 'axios';

const LoginPage = () => {
  const handleLogin = async () => {
    try {
      const response = await axios.get('/auth/google');
      // Handle successful login (redirect or set token/session)
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  return (
    <div>
      <h2>Login with Google</h2>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default LoginPage;
